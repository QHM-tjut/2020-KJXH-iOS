//
//  MYMainViewController.m
//  MYBlueToothTool
//
//  Created by 齐浩铭 on 2021/1/20.
//

#define IS_LANDSCAPE (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]))

#define SCREEN_WIDTH (IS_LANDSCAPE ? [[UIScreen mainScreen] bounds].size.height : [[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT (IS_LANDSCAPE ? [[UIScreen mainScreen] bounds].size.width : [[UIScreen mainScreen] bounds].size.height)
#define SIZE self.view.bounds.size

#import "MYMainViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import "MYScanArrayViewController.h"


@interface MYMainViewController ()

@property (nonatomic,strong,readwrite)UIButton *btn;
@property (nonatomic,strong,readwrite)UILabel *MYUUID;
@property (nonatomic,strong,readwrite)UILabel *demoTitle;

- (void)btnLayOut;

@end

@implementation MYMainViewController

- (instancetype)init{
    self = [super init];
    if (self){
        self.view.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

#pragma mark -

- (void)viewDidLoad {
    [super viewDidLoad];
    _btn = [[UIButton alloc] init];
    _MYUUID = [[UILabel alloc] init];
    _demoTitle = [[UILabel alloc] init];
    [self btnLayOut];
    [self setMYUUIDLayOut];
    [self setDemoTitleLayOut];
    
    
    
    [self.view addSubview:_MYUUID];
    
}

//设置按钮的位置
- (void)btnLayOut{
    _btn.frame = CGRectMake(SIZE.width / 2 - 80, 400, 160, 60);
    _btn.backgroundColor = [UIColor orangeColor];
    _btn.layer.cornerRadius = 10;
    _btn.layer.borderWidth = 2;
    _btn.layer.masksToBounds = YES;
    [_btn setTitle:@"开始扫描蓝牙" forState:UIControlStateNormal];
    _btn.titleLabel.textAlignment = NSTextAlignmentCenter;
    _btn.titleLabel.font = [UIFont systemFontOfSize:20];
    [_btn setTitle:@"👀" forState:UIControlStateHighlighted];
    [self.view addSubview:_btn];
    [_btn addTarget:self action:@selector(pushBlueToothTableView) forControlEvents:UIControlEventTouchUpInside];
}

- (void)setMYUUIDLayOut{
    _MYUUID.frame = CGRectMake(0, SIZE.height/2 + 100, SIZE.width, 30);
    _MYUUID.text =  [self getSelfUUID];
    _MYUUID.font = [UIFont systemFontOfSize:20];
    _MYUUID.textAlignment = NSTextAlignmentCenter;
    
    
    
    [self.view addSubview:_MYUUID];
}

- (void)pushBlueToothTableView{
    MYScanArrayViewController *scanArrayViewController = [[MYScanArrayViewController alloc] init];
    [self.navigationController pushViewController:scanArrayViewController animated:YES];
    
}


- (void)setDemoTitleLayOut{
    _demoTitle.frame = CGRectMake(SIZE.width / 2  - 130, 100, 260, 40);
    _demoTitle.numberOfLines = 0;
    _demoTitle.text = @"自己实现蓝牙扫描demo";
    _demoTitle.font = [UIFont systemFontOfSize:24];
    [self.view addSubview:_demoTitle];
}

- (NSString *)getSelfUUID{
    CFUUIDRef puuid = CFUUIDCreate(nil);
    CFStringRef uuidString = CFUUIDCreateString(nil, puuid);
    NSString *result = (NSString *)CFBridgingRelease(CFStringCreateCopy(NULL, uuidString));
    NSMutableString *tmpResult = result.mutableCopy;
    return tmpResult;

}


@end
