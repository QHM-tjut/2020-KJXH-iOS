//
//  MYScanArrayViewController.m
//  MYBlueToothTool
//
//  Created by 齐浩铭 on 2021/1/20.
//

#import "MYScanArrayViewController.h"
#import "MYBlueToothDeviceManager.h"
#import "MYTableViewCell.h"



@interface MYScanArrayViewController ()
<UITableViewDelegate,UITableViewDataSource,MYDeviceManagerDelegate>

@property (nonatomic,strong,readwrite) MYBlueToothDeviceManager *blutToothDevceManager;

@end

@implementation MYScanArrayViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.blutToothDevceManager = [MYBlueToothDeviceManager blueToothDeviceManager];
    
    //刷新代码
    UIRefreshControl *refresh = [[UIRefreshControl alloc]init];
    refresh.attributedTitle = [[NSAttributedString alloc]initWithString:@"下拉刷新"];
    [refresh addTarget:self action:@selector(hahaha) forControlEvents:UIControlEventValueChanged];
    self.tableView.refreshControl = refresh;

    _tableView.delegate = self;
    _tableView.dataSource = self;
    _blutToothDevceManager.delegate = self;
    [self.view addSubview:_tableView];
}


//没用
- (void)sort {
    MYBlueToothDeviceManager *manager = [MYBlueToothDeviceManager blueToothDeviceManager];
    self.blueToothArray = [manager.deviceArray copy];
    //按距离排序
    NSSortDescriptor *distance = [NSSortDescriptor sortDescriptorWithKey:@"distance" ascending:YES];
    self.blueToothArray = [[self.blueToothArray sortedArrayUsingDescriptors:@[distance]] copy];
    [self.tableView reloadData];
}


//刷新时执行的方法
- (void)hahaha{
    self.blueToothArray = [self.blutToothDevceManager.deviceArray copy];
//    NSSortDescriptor *distance = [NSSortDescriptor sortDescriptorWithKey:@"distance" ascending:YES];
//    self.blueToothArray = [[self.blueToothArray sortedArrayUsingDescriptors:@[distance]] copy];
    
    
    [self.tableView.refreshControl beginRefreshing];
    [self.tableView reloadData];
    if ([self.tableView.refreshControl isRefreshing]){
        [self.tableView.refreshControl endRefreshing];
    }
}


#pragma delegate and dataSource --

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.blueToothArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reusedID = @"ID";
    MYTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reusedID];
    if (!cell){
        cell = [[MYTableViewCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:reusedID];
    }
    [cell loadDataFrom:self.blueToothArray[indexPath.row]];
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 78;
}

- (void)reloadDataInManager:(MYBlueToothDeviceManager *)manager{
    self.blueToothArray = [manager.deviceArray copy];
    [self.tableView reloadData];
}


@end
