//
//  MYBlueToothDeviceManager.m
//  MYBlueToothTool
//
//  Created by 齐浩铭 on 2021/1/23.
//

#import "MYBlueToothDeviceManager.h"
#import <CoreBluetooth/CoreBluetooth.h>




@interface MYBlueToothDeviceManager()<CBCentralManagerDelegate>

@property (nonatomic,strong,readwrite) CBCentralManager *cbManager;

@end

@implementation MYBlueToothDeviceManager

+ (instancetype)blueToothDeviceManager{
    static MYBlueToothDeviceManager *blueToothDeviceManager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        blueToothDeviceManager = [[MYBlueToothDeviceManager alloc] init];
    });
    return blueToothDeviceManager;
}


- (instancetype)init
{
    self = [super init];
    if (self) {
        self.deviceArray = [NSMutableArray array];
        self.deviceIDArray = [NSMutableArray array];
        self.cbManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    }
    return self;
}

- (void)discoverDevice{
    [self.cbManager scanForPeripheralsWithServices:nil options:nil];
}
// Delegate
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    switch (central.state) {
        case CBManagerStatePoweredOn:
            NSLog(@"PowerON");
            [self.cbManager scanForPeripheralsWithServices:nil options:nil];
            break;
        default:
            break;
    }
}

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *, id> *)advertisementData RSSI:(NSNumber *)RSSI{
    NSLog(@"%@",peripheral);
    MYBlueToothModel *model = [[MYBlueToothModel alloc] init];
    model.name = [peripheral.name copy];
    model.qiangdu = RSSI;
    model.deviceID = [NSString stringWithFormat:@"%@",peripheral.identifier];
    //遍历ID列表查看是否有这个设备
    //OC的遍历也不会用
    int flag = 0;//1为有
    for (int i = 0 ; i < self.deviceIDArray.count ; i++){
        if ([self.deviceIDArray[i] isEqual:peripheral.identifier.UUIDString]){
            flag = 1;
            if (![self.deviceArray containsObject:model]){
                //更新不会写
                [self.deviceArray replaceObjectAtIndex:i withObject:model];
                if (self.delegate && [self.delegate respondsToSelector:@selector(reloadDataInManager:)]){
                    [self.delegate reloadDataInManager:self];
                    
                }
            }
            break;
        }
    }
    
    if (!flag){
        [self.deviceIDArray addObject:peripheral.identifier.UUIDString];
        [self.deviceArray addObject:model];
        //更新不会写
        if (self.delegate && [self.delegate respondsToSelector:@selector(reloadDataInManager:)]){
            [self.delegate reloadDataInManager:self];
        }

    }
    flag = 0;
    
}


@end
