//
//  MYBlueToothDeviceManager.h
//  MYBlueToothTool
//
//  Created by 齐浩铭 on 2021/1/23.
//

#import <Foundation/Foundation.h>
#import "MYBlueToothModel.h"


NS_ASSUME_NONNULL_BEGIN

@class MYBlueToothDeviceManager;
@protocol MYDeviceManagerDelegate <NSObject>

- (void)reloadDataInManager:(MYBlueToothDeviceManager *)manager;

@end


@interface MYBlueToothDeviceManager : NSObject

@property (nonatomic,strong,readwrite) NSMutableArray<MYBlueToothModel*> *deviceArray;
@property (nonatomic,strong,readwrite) NSMutableArray<NSString*> *deviceIDArray;
@property (nonatomic,weak,readwrite) id <MYDeviceManagerDelegate>delegate;


- (void)discoverDevice;
+ (instancetype)blueToothDeviceManager;

@end

NS_ASSUME_NONNULL_END
