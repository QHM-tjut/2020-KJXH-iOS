//
//  MYTableViewController.m
//  MYBlueToothTool
//
//  Created by 齐浩铭 on 2021/1/20.
//

#import "MYTableViewController.h"

@interface MYTableViewController ()<UITableViewDelegate>

@end

@implementation MYTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

@end
