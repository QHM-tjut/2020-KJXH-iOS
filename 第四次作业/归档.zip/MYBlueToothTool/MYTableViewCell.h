//
//  MYTableViewCell.h
//  MYBlueToothTool
//
//  Created by 齐浩铭 on 2021/1/22.
//

#import <UIKit/UIKit.h>
@class  MYBlueToothModel;

NS_ASSUME_NONNULL_BEGIN



@interface MYTableViewCell : UITableViewCell

- (void)loadDataFrom:(MYBlueToothModel *)Model;

@end

NS_ASSUME_NONNULL_END
