//
//  MYTableViewCell.m
//  MYBlueToothTool
//
//  Created by 齐浩铭 on 2021/1/22.
//

#import "MYTableViewCell.h"
#import "MYBlueToothModel.h"
@interface MYTableViewCell()

@property (nonatomic, strong, readwrite) UILabel *nameLabel;
@property (nonatomic, strong, readwrite) UILabel *deviceIDLabel;
@property (nonatomic, strong, readwrite) UILabel *intensityLabel;
@property (nonatomic, strong, readwrite) UILabel *distanceLabel;

@end


@implementation MYTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(nullable NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:({
            self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 15, 170, 30)];
            self.nameLabel.font = [UIFont systemFontOfSize:16];
            self.nameLabel.textColor = [UIColor blackColor];
            self.nameLabel.lineBreakMode = NSLineBreakByTruncatingTail;
            self.nameLabel;
        })];
        
        [self.contentView addSubview:({
            self.deviceIDLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 54, 170, 20)];
            self.deviceIDLabel.font = [UIFont systemFontOfSize:12];
            self.deviceIDLabel.textColor = [UIColor blackColor];
            self.deviceIDLabel.lineBreakMode = NSLineBreakByTruncatingTail;
            self.deviceIDLabel;
        })];
        
        [self.contentView addSubview:({
            self.intensityLabel = [[UILabel alloc] initWithFrame:CGRectMake(200, 54, 70, 20)];
            self.intensityLabel.font = [UIFont systemFontOfSize:14];
            self.intensityLabel.textColor = [UIColor blackColor];
            self.intensityLabel.lineBreakMode = NSLineBreakByTruncatingTail;
            self.intensityLabel;
        })];
        
        [self.contentView addSubview:({
            self.distanceLabel = [[UILabel alloc] initWithFrame:CGRectMake(280, 54, 80, 20)];
            self.distanceLabel.font = [UIFont systemFontOfSize:14];
            self.distanceLabel.textColor = [UIColor blackColor];
            self.distanceLabel.lineBreakMode = NSLineBreakByTruncatingTail;
            self.distanceLabel;
        })];
    }
    return self;
}

- (void)loadDataFrom:(MYBlueToothModel *)Model{
    self.deviceIDLabel.text = [NSString stringWithFormat:@"%@",Model.deviceID];
    self.nameLabel.text = [Model.name copy];
    self.distanceLabel.text = [NSString stringWithFormat:@"距离：%f",[self caculateDistance:Model.qiangdu]];
    self.intensityLabel.text = [NSString stringWithFormat:@"强度：%ld",Model.qiangdu.integerValue];
    
}

-(float)caculateDistance:(NSNumber *)RSSI {
    float power = (labs([RSSI integerValue]) - 59) / (10 * 2.0);
    float result = powf(10.0f, power);
    return result;
}



@end
