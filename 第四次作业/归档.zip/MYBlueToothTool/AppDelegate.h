//
//  AppDelegate.h
//  MYBlueToothTool
//
//  Created by 齐浩铭 on 2021/1/20.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong,nonatomic,readwrite) UIWindow *window;

@end

