//
//  MYScanArrayViewController.h
//  MYBlueToothTool
//
//  Created by 齐浩铭 on 2021/1/20.
//

#import <UIKit/UIKit.h>
#import "MYBlueToothModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MYScanArrayViewController : UIViewController

@property (nonatomic,strong,readwrite) UITableView *tableView;
@property (nonatomic,strong,readwrite) NSArray *blueToothArray;



@end

NS_ASSUME_NONNULL_END
