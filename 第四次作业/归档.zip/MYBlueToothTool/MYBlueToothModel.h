//
//  MYBlueToothModel.h
//  MYBlueToothTool
//
//  Created by 齐浩铭 on 2021/1/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MYBlueToothModel : NSObject

@property (nonatomic,strong,readwrite) NSString *name;
@property (nonatomic,strong,readwrite) NSString *deviceID;
@property (nonatomic,strong,readwrite) NSString *distance;
@property (nonatomic,assign,readwrite) NSNumber *qiangdu;

@end

NS_ASSUME_NONNULL_END
