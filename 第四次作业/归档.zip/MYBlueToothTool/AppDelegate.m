//
//  AppDelegate.m
//  MYBlueToothTool
//
//  Created by 齐浩铭 on 2021/1/20.
//

#import "AppDelegate.h"
#import "MYMainViewController.h"

#import "MYBlueToothDeviceManager.h"


@interface AppDelegate ()

@end



@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    
    MYMainViewController *mainViewController = [[MYMainViewController alloc] init];
    UINavigationController *rootNavigationController = [[UINavigationController alloc] initWithRootViewController:mainViewController];
    [_window setRootViewController:rootNavigationController];
    [_window makeKeyAndVisible];
    return YES;
}

@end
