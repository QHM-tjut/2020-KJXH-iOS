//
//  LoginJudger.m
//  OC实现后端银行作业
//
//  Created by 齐浩铭 on 2020/12/30.
//

#import "LoginJudger.h"

@implementation LoginJudger

-(BOOL)JudgeId:(int*)id andWithAccentCnt:(NSUInteger)accentCnt
{
    //while(id != '*'){ //不起作用 ， 不能输入初数字之外的符号。。
    printf("请输入登录id：");
    scanf("%d",id);
    printf("请稍后。。。。。");
    sleep(3);
    if (*id <= accentCnt && *id != 0){
        printf("登录成功");
        return YES;
    }else if (*id == 0){
        printf("退出\n");
        return NO;
    }else{
        printf("账户不存在,请从新输入\n");
        return NO;
    }
    //}
    return YES;
}

@end
