//
//  LoginJudger.h
//  OC实现后端银行作业
//
//  Created by 齐浩铭 on 2020/12/30.
//  判断账号登录id

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginJudger : NSObject

-(BOOL)JudgeId:(int*)id andWithAccentCnt:(NSUInteger)accentCnt;
@end

NS_ASSUME_NONNULL_END
