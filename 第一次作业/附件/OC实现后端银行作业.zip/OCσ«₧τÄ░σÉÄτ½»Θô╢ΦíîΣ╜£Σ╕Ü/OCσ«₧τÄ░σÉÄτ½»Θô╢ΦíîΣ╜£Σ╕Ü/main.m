#import <Foundation/Foundation.h>
#import "BankAccent.h"
#import "HMDate.h"//自己写的保存时间的类
#import "LoginJudger.h"
#define NSLog(FORMAT, ...) printf("%s\n", [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String])//NSLog不输出时间戳等参数
int main()
{
    int i;//功能选择数字
    int id = 0;//登录ID
    @autoreleasepool {
        HMDate *mainTime = [[HMDate alloc]initWithNowTime]; //主时间线，对时间的快进也是对主时间的操作
        NSMutableArray *accentList = [NSMutableArray array];//银行账户列表
        NSUInteger accentCnt = 0; //银行账户计数...
        LoginJudger *Judger = [[LoginJudger alloc]init];
        while (1)
        while (1){
            printf("========欢迎来到OC银行界面========\n");
            printf("1.公司账户    2.个人账户\n");
            printf("3.上帝时间    4.退出系统\n");
            printf("input:");
            scanf("%d",&i);
            if (i == 4){
                printf("淦谢您的使用，再见👋\n\n");
                break;
#pragma mark -
            }else if (i == 1){
                printf("========公司账户========\n");
                printf("1.入职开户         2.查询余额\n");
                printf("3.取钱到个人账户    4.退回\ninput:");
                int j;
                scanf("%d",&j);
#pragma mark 入职开户
                if (j == 1){
                    [accentList addObject:[[BankAccent alloc]initWithMaintime:mainTime]];//以主时间线初始化一个新的银行账户并保存到accentlist
                    accentCnt = [accentList count];
                    printf("入职开户成功！\n账号id：%ld\n",accentCnt);
                    //NSLog(@"开户时间为%@",[accentList[accentCnt] rolldate]);//次数Xcode有bug
                    //NSLog(@"开户时间为%lu年%lu月%lu日\n",mainTime.year,mainTime.month,mainTime.day);
                    NSLog(@"%ld",[[accentList[0] rolldate] year]);
                    [[accentList objectAtIndex:(accentCnt-1)] SetMonthlySalary];
#pragma mark 查询余额
                }else if (j == 2){
                    if ([Judger JudgeId:&id andWithAccentCnt:[accentList count]])//判断输入id是否合规
                    {
                        //NSLog(@"%ld",[accentList[id - 1] balance]);
                        [accentList[id - 1] updateMontyWithMaintime:mainTime];
                        [accentList[id - 1] showBalance];
                        //NSLog(@"%ld",accentList[0].balance);//此处不能用。访问
//                        if ([[accentList objectAtIndex:0] isKindOfClass:[BankAccent class]]){
//                            NSLog(@"%ld",[accentList objectAtIndex:0].balance);
//                        }
                    }
                    //NSLog(@"账户%d的余额为%ld",id,);

#pragma mark 取钱到个人账户
                }else if (j == 3){
                    [Judger JudgeId:&id andWithAccentCnt:[accentList count]];
                    [accentList[id-1] updateMontyWithMaintime:mainTime];
                    NSLog(@"请输入要取的💰");
                    int takeUpMoney = 0;
                    NSInteger haveMoney = [accentList[id-1] balance];
                    scanf("%d",&takeUpMoney);
                    if (takeUpMoney >= [accentList[id - 1] balance]){
                        [accentList[id - 1] setBalance:haveMoney - takeUpMoney];
                        NSLog(@"取钱成功\n");
                    }else{
                        NSLog(@"余额不足\n");
                    }

#pragma mark 返回
                }else if (j == 4){
                    break;
                }else{
                    printf("输入错误，请从新输入\n");
                }
#pragma mark -
            }else if (i == 2){
                printf("2");
#pragma mark -
            }else if (i == 3){
                NSLog(@"========上帝时间========\n");
                NSLog(@"在此界面你可以调整当前世界的时间来达到快速获得工资的目的😊\n");
                NSLog(@"请输入快进到的时间：");
                int addtime = 0;
                scanf("%d",&addtime);
                mainTime.month += addtime;
                if (mainTime.month > 12){
                    mainTime.month -= 12;
                    mainTime.year++;
                }
            }else{
                printf("输入错误🙅,请从新输入\n\n");
            }
        }
    }


    return 0;
}

//
//#import <Foundation/Foundation.h>
//#import "BankAccent.h"
//#import "HMDate.h"//自己写的保存时间的类
//#import "LoginJudger.h"
//#define NSLog(FORMAT, ...) printf("%s\n", [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String])//NSLog不输出时间戳等参数
//
//int main()
//{
//    HMDate *now = [[HMDate alloc]initWithNowTime];
//    BankAccent *accent = [[BankAccent alloc]initWithMaintime:now];
//    NSLog(@"%ld",[[accent rolldate] year]);
//    return 0;
//}
