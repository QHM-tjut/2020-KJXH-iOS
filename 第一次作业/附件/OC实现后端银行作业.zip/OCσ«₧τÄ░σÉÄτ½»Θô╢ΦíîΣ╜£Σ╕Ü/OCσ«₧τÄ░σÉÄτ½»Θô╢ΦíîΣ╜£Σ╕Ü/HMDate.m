//
//  HMDate.m
//  test 2
//
//  Created by 齐浩铭 on 2020/12/29.
//

#import "HMDate.h"

@implementation HMDate
- (instancetype)initWithNowTime;
{
    NSDate *now = [[NSDate alloc]init];
    NSCalendar *gregorian = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
    unsigned unitFlag = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay;
    NSDateComponents *comp = [gregorian components:unitFlag fromDate:now];
    self = [super init];
    if (self) {
        _year = comp.year;
        _month = comp.month;
        _day = comp.day;
    }
    return self;
}
@end
