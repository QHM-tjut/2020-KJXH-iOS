//
//  BankAccent.h
//  OC实现后端银行作业
//
//  Created by 齐浩铭 on 2020/12/28.
//

#import <Foundation/Foundation.h>
#import "HMDate.h"
#define NSLog(FORMAT, ...) printf("%s\n", [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String])//NSLog不输出时间戳等参数
NS_ASSUME_NONNULL_BEGIN


@interface BankAccent : NSObject
@property (nonatomic) NSInteger monthlySalary;//月工资
@property NSInteger id;//手动输入
@property NSInteger balance;//账户余额
@property HMDate *rolldate;//开户日期
@property NSInteger selfMoney; //个人账户中的钱
@property NSInteger liftTime; //换成钱的月数
-(void)SetMonthlySalary;  //设置基础工资
-(void)updateMontyWithMaintime:(HMDate*)mainTime; //改变时间后更新账户中的钱数
-(instancetype)initWithMaintime:(HMDate *)maintime; //重写带有初始化开户时间的init
-(void)showBalance;

@end

NS_ASSUME_NONNULL_END
