//
//  BankAccent.m
//  OC实现后端银行作业
//
//  Created by 齐浩铭 on 2020/12/28.
//

#import "BankAccent.h"


@implementation BankAccent

-(void)SetMonthlySalary
{
    printf("正在设置基础月工资为3000元。。。。。。\n");
    //monthlySalary = 3000;
    _monthlySalary = 3000;
    sleep(1);
}

-(instancetype)initWithMaintime:(HMDate *)maintime
{
    self = [super init];
    if (self) {
        [_rolldate setYear:maintime.year];
        [_rolldate setMonth:maintime.month];
        [_rolldate setDay:maintime.day];
        //NSLog(@"this is miantime.year = %ld\n",maintime.year);
        //问题：怎样让一个对象继承另一个对象的值
    }
    return self;
}

-(void)showBalance
{
    NSLog(@"\n========账户余额查询========\n");
    NSLog(@"\n账户余额：%ld",_balance);
}

-(void)updateMontyWithMaintime:(HMDate*)mainTime
{
    NSInteger monthInterval = (mainTime.year - _rolldate.year)*10 + (mainTime.month - _rolldate.month) - _liftTime;
    _liftTime = monthInterval;
    _balance = monthInterval * _monthlySalary;
}


@end
