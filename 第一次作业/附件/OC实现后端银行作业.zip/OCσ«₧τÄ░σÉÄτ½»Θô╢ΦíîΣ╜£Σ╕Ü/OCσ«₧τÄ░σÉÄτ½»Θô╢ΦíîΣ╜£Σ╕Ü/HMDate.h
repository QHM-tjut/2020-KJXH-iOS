#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HMDate : NSObject
@property NSInteger year;
@property NSInteger month;
@property NSInteger day;

- (instancetype)initWithNowTime;


@end
NS_ASSUME_NONNULL_END

