#import <Foundation/Foundation.h>
#import "Person.h"


int main()
{
    NSMutableArray *personList = [NSMutableArray array];
    [personList addObject:[Person new]];
    [personList[0] setName:@"小明"];
    
    NSLog(@"%@",[[personList objectAtIndex:0] name]);
    return 0;
}
