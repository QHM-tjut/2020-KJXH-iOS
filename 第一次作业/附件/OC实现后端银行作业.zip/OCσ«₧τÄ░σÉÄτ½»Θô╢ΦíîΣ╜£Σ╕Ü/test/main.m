#import <Foundation/Foundation.h>

int main()
{
   
    // 获取代表公历的NSCalendar对象
    NSCalendar *cal = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    //NSCalendar *cal = [NSCalendar currentCalendar]; // 和第七行相等
    // 获取当前日期
    NSDate *now = [[NSDate alloc]init];
      // 定义一个时间字段的旗标，指定将会获取指定年、月、日、时、分、秒的信息
      unsigned unitFlags = NSCalendarUnitYear |
       NSCalendarUnitMonth |  NSCalendarUnitDay;
      // 获取不同时间字段的信息
    NSDateComponents *comp = [cal components: unitFlags fromDate:now];
    NSLog(@"%@",comp);
    
    
    return 0;
}

