//
//  HMTableViewCell.m
//  Hello World APP
//
//  Created by 齐浩铭 on 2021/1/17.
//

#import "HMTableViewCell.h"




@interface HMTableViewCell()

@property (nonatomic,strong,readwrite) UILabel *titleLabel;
@property (nonatomic,strong,readwrite) UILabel *sourceLabel;
@property (nonatomic,strong,readwrite) UILabel *numberLabel;
@property (nonatomic,strong,readwrite) UILabel *timeLabel;
@property (nonatomic,strong,readwrite) UIImageView *rightImageView;
@property (nonatomic,strong,readwrite) UIButton *button;

@end


@implementation HMTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self){
        [self.contentView addSubview:({
            _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 15, 300, 50)];
//            _titleLabel.text = @"新闻标题";
            _titleLabel.font = [UIFont systemFontOfSize:18];
            _titleLabel.textColor = [UIColor blackColor];
//            _titleLabel.backgroundColor = [UIColor redColor];
            _titleLabel;
        })];
        
        [self.contentView addSubview:({
            _sourceLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 80, 50, 20)];
            _sourceLabel.font = [UIFont systemFontOfSize:12];
            _sourceLabel.textColor = [UIColor blackColor];
//            _sourceLabel.text = @"Bilibili!";
//            _sourceLabel.backgroundColor = [UIColor redColor];
            _sourceLabel;
        })];
        
        
        [self.contentView addSubview:({
            _numberLabel = [[UILabel alloc] initWithFrame:CGRectMake(100, 80, 50, 20)];
            _numberLabel.font = [UIFont systemFontOfSize:12];
            _numberLabel.textColor = [UIColor blackColor];
//            _numberLabel.text = @"12345评论";
//            _numberLabel.backgroundColor = [UIColor redColor];
            _numberLabel;
        })];
        
        [self.contentView addSubview:({
            _timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(150, 80, 50, 20)];
            _timeLabel.font = [UIFont systemFontOfSize:12];
            _timeLabel.textColor = [UIColor blackColor];
//            _timeLabel.text = @"3分钟前";
//            _timeLabel.backgroundColor = [UIColor redColor];
            _timeLabel;
        })];
        
        [self.contentView addSubview:({
            _rightImageView = [[UIImageView alloc] initWithFrame:CGRectMake(330, 15, 70, 70)];
            _rightImageView.backgroundColor = [UIColor redColor];
            _rightImageView.image = [UIImage imageNamed:@"icon.bundle/icon.png"];
            _rightImageView;
        })];
        
        [self.contentView addSubview:({
            _button = [[UIButton alloc] init];
            _button.frame = CGRectMake(290, 80, 20, 20);
            _button.backgroundColor = [UIColor lightGrayColor];
            [_button setTitle:@"X" forState:UIControlStateNormal];
            [_button setTitle:@"√" forState:UIControlStateHighlighted];
            _button;
        })];
        
        
        
        
    }
    return self;
}


- (void)layOutTableViewCell{
    _titleLabel.text = @"新闻标题";
    
    _sourceLabel.text = @"Bilibili!";
    [_sourceLabel sizeToFit];
    
    _numberLabel.text = @"12345评论";
    [_numberLabel sizeToFit];
    _numberLabel.frame = CGRectMake(_sourceLabel.frame.origin.x + 15 + _sourceLabel.frame.size.width, _numberLabel.frame.origin.y, _numberLabel.frame.size.width, _numberLabel.frame.size.height);
    
    _timeLabel.text = @"3分钟前";
    [_timeLabel sizeToFit];
    _timeLabel.frame = CGRectMake(_numberLabel.frame.origin.x + 15 + _numberLabel.frame.size.width, _timeLabel.frame.origin.y, _timeLabel.frame.size.width, _timeLabel.frame.size.height);
    
    
    [_button addTarget:self action:@selector(deleteButtonDidTouch) forControlEvents:(UIControlEventTouchUpInside)];
    
}

- (void)deleteButtonDidTouch{
    if (self.delegate && [self.delegate respondsToSelector:@selector(TableViewCell:deleteButten:)]){
        [self.delegate TableViewCell:self deleteButten:_button];
    }
}



@end
