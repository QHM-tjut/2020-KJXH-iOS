//
//  AppDelegate.m
//  Hello World APP
//
//  Created by 齐浩铭 on 2021/1/7.
//

#import "AppDelegate.h"
#import "MYNewsViewController.h"
#import "HMVideoViewController.h"
#import "HMRecommendViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame: [[UIScreen mainScreen] bounds]];
    
    
    UITabBarController *tabBarController = [[UITabBarController alloc] init];
    
    //创建新闻页面的ViewController
    MYNewsViewController *newsViewController = [[MYNewsViewController alloc] init];
    //创建视频界面的viewController
    HMVideoViewController *videoController= [[HMVideoViewController alloc] init];
    
    // 推荐界面的ViewController
    HMRecommendViewController *recommendViewController = [[HMRecommendViewController alloc] init];
    
    UIViewController *controller4 = [[UIViewController alloc] init];
    controller4.view.backgroundColor = [UIColor lightGrayColor];
    controller4.tabBarItem.title = @"我的";
    controller4.tabBarItem.image = [UIImage imageNamed:@"icon.bundle/home@2x.png"];
    controller4.tabBarItem.selectedImage = [UIImage imageNamed:@"home_selected@2x.png"];
    
    
    [tabBarController setViewControllers:@[newsViewController,videoController,recommendViewController,controller4]];
     
    
    UINavigationController *rootNavigationController = [[UINavigationController alloc] initWithRootViewController:tabBarController];
    self.window.rootViewController =rootNavigationController;
    [self.window makeKeyAndVisible];

    
    
    return YES;
}


@end
