//
//  HMTableViewCell.h
//  Hello World APP
//
//  Created by 齐浩铭 on 2021/1/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class HMTableViewCell;

@protocol HMTableViewCellDelegate <NSObject>

- (void)TableViewCell:(HMTableViewCell *)tableviewcell deleteButten:(UIButton *)button;

@end

@interface HMTableViewCell : UITableViewCell

@property (nonatomic,weak,readwrite) id<HMTableViewCellDelegate> delegate;

- (void)layOutTableViewCell;

@end

NS_ASSUME_NONNULL_END
