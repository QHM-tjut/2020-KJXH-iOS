//
//  AppDelegate.h
//  Hello World APP
//
//  Created by 齐浩铭 on 2021/1/7.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;

@end

