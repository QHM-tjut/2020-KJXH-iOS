//
//  HMRecommendViewController.m
//  Hello World APP
//
//  Created by 齐浩铭 on 2021/1/16.
//

#import "HMRecommendViewController.h"

@implementation HMRecommendViewController

- (instancetype)init{
    self = [super init];
    if (self){
        //self.view.backgroundColor = [UIColor yellowColor];
        self.tabBarItem.title = @"推荐";
        self.tabBarItem.image = [UIImage imageNamed:@"icon.bundle/like@2x.png"];
        self.tabBarItem.selectedImage = [UIImage imageNamed:@"icon.bundle/like_selected@2x.png"];
    }
    return self;
}

- (void)locAction {
    NSLog(@"This is yello view action");
}


- (void)viewDidLoad {
    [super viewDidLoad];
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    scrollView.contentSize = CGSizeMake(self.view.bounds.size.width*5, self.view.bounds.size.height);
    //开启翻页效果
    scrollView.pagingEnabled = YES;
    
    
    //创建5个不同颜色的view
    NSArray *colorArray = @[[UIColor redColor],[UIColor yellowColor],[UIColor greenColor],[UIColor blueColor],[UIColor lightGrayColor]];
    scrollView.backgroundColor = [UIColor whiteColor];
    
    for (int i = 0 ; i < 5 ; i++){
        [scrollView addSubview:({
            UIView *view = [[UIView alloc] initWithFrame:CGRectMake(self.view.bounds.size.width * i, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
            view.backgroundColor = colorArray[i];
            view;
        })];
    }
    
    UIView *yelloView = [[UIView alloc] init];
    UITapGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(locAction)];
    [yelloView addGestureRecognizer:gestureRecognizer];
    yelloView.frame = CGRectMake(100, 100, 100, 100);
    yelloView.backgroundColor = [UIColor yellowColor];
    
    [self.view addSubview:scrollView];
    [scrollView addSubview:yelloView];
}

@end





//UIView *view1 = [[UIView alloc] initWithFrame:CGRectMake(self.view.bounds.size.width * i, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
